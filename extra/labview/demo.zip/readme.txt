Toupcam Labview demo
1. LVDemo1.vi is a Labview program which works with one camera.
   The LVDemo1.png is the screen snapshot of the UI of the running program.

2. LVDemo2.vi is a Labview program which opens two cameras and control them respectively.
   The LVDemo2.png is the screen snapshot of the UI of the running program.

3. LVdemo3.vi: open camera, preview video, captuare (still) image, set the preview resolution, auto exposure, bitdepth, color adjustment, white (black) balance, digital binning, flat (dark) field corrction, etc.